name        "opsworks_commons"
description "Common recipes and libraries"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends "dependencies"
