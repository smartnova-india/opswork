Chef::Log.info "Not needed with Chef 11.x (x >= 8) anymore."
