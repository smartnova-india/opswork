service "memcached" do
  action :nothing
end